#!/bin/bash

input_file=$1

file_name=$(basename $input_file | sed 's/.tex//g')
echo $file_name

sed_mask="s/output/sections\/${file_name}\/output/g"
echo $sed_mask
# exit 0

cat $input_file | \
  grep -E '.*output_.*\.png' | \
  sed $sed_mask
