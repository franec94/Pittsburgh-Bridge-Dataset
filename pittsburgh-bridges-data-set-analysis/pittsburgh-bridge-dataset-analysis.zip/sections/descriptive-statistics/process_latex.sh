cat descriptive-statistics.tex | grep -E '.*output_.*\.png' | sed 's/output/sections\descriptive-statistics\output/g'
